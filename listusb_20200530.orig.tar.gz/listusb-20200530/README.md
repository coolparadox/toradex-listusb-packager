# listusb
listusb is an example application to list USB devices
